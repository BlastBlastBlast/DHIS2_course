document.getElementById('clickMe').addEventListener('click', () => {
  alert('Button clicked! You are ready to develop with Vite.');
});
